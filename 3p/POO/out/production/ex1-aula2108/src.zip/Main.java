public class Main {
    public static void main(String[] args) {

        System.out.println("Teste com inteiros");
        Area area1 = new Area(10, 8);
        area1.exibirValores();
        System.out.println("Área do Triângulo: " + area1.triangulo());
        System.out.println("Área do Quadrado/Retângulo: " + area1.quadrado());
        System.out.println();

        System.out.println("--- Teste com ponto flutuante ---");
        Area area2 = new Area(7.5, 2.0);
        area2.exibirValores();
        System.out.println("Área do Triângulo: " + area2.triangulo());
        System.out.println("Área do Quadrado/Retângulo: " + area2.quadrado());
        System.out.println();

        System.out.println("Teste com texto (usando vírgula)");
        Area area3 = new Area("15,5", "10");
        area3.exibirValores();
        System.out.println("Área do Triângulo: " + area3.triangulo());
        System.out.println("Área do Quadrado/Retângulo: " + area3.quadrado());
        System.out.println();

        System.out.println("Teste com texto inválido");
        Area area4 = new Area("teste", "20");
        area4.exibirValores();
        System.out.println("Área do Triângulo: " + area4.triangulo());
        System.out.println("Área do Quadrado/Retângulo: " + area4.quadrado());
    }
}