import java.util.ArrayList;
public class Pedido {
    Cliente cliente;
    ArrayList<Prato> pratos;

    public Pedido(){
        this.pratos = new ArrayList<Prato>();
    }

    public void exibirPedido(){

    }
}
