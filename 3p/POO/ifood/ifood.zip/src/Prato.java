public class Prato {
    private String nome;
    private double preco;

    public void exibirDetalhes(){

    }

    public String getNome(){
        return this.nome;
    }
    public void setNome(){
        this.nome = nome;
    }
    public double getPreco(){
        return this.preco;
    }
    public void setPreco(double preco){
        this.preco = preco;
    }
}
