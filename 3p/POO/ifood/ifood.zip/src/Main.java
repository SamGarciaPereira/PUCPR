import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int opcao = -1;
        int qtdPratos = -1;
        Scanner input = new Scanner(System.in);
        Cliente c1 = new Cliente();
        Prato pratos = new Prato();



        while(opcao != 9){
            System.out.println("======= IFOOD =======");
            System.out.println("(1) Cadastrar novo cliente");
            System.out.println("(9) Encerrar programa");
            System.out.print("Insira sua opção: ");

            opcao = input.nextInt();

            if(opcao == 1){
                System.out.print("Insira seu nome: ");
                c1.setNome(input.nextLine());

                System.out.print("Insira seu telefone: ");
                c1.setTelefone(input.nextLine());

                System.out.println("Insira a quantidade de pratos que deseja comprar: ");
                qtdPratos = input.nextInt();

                if(qtdPratos < 5){
                    System.out.println("Precisa adicionar mais de 5 pratos!");
                }else{
                    while(qtdPratos > 5)
                        System.out.println("Insira o nome do prato " + qtdPratos+1 + ": ");
                        pratos.add(new Prato(input.nextLine(), input.nextDouble()));

                    qtdPratos++;
                }




            }else if(opcao == 9){
                System.out.println("Encerrando...");
            }else{
                System.out.println("Opção inválida, tente novamente!");
            }


        }
    }
}